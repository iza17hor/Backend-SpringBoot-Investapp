package com.example.X;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XApplicationTests {

	@Test
	void contextLoads() {
	}

}
