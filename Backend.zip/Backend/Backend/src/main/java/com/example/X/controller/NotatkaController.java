package com.example.X.controller;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import com.example.X.model.Notatka;
import com.example.X.repository.NotatkaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:8080")
@RestController
@RequestMapping("/api")
public class NotatkaController {

    @Autowired
    NotatkaRepository notatkiRepository;
    @GetMapping("/notatki")
    public ResponseEntity<List<Notatka>> getAllNotatki(@RequestParam(required = false) String title) {
        try {
            List<Notatka> notatki = new ArrayList<Notatka>();
            if (title == null)
                notatkiRepository.findAll().forEach(notatki::add);
            else
                notatkiRepository.findByTitleContaining(title).forEach(notatki::add);
            if (notatki.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(notatki, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    @GetMapping("/notatki/{id}")
    public ResponseEntity<Notatka> getNotatkiById(@PathVariable("id") long id) {
        Optional<Notatka> notatkiData = notatkiRepository.findById(id);
        if (notatkiData.isPresent()) {
            return new ResponseEntity<>(notatkiData.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    @PostMapping("/notatki")
    public ResponseEntity<Notatka> createNotatki(@RequestBody Notatka notatki) {
        try {
            Notatka _notatka = notatkiRepository
                    .save(new Notatka(notatki.getTitle(), notatki.getDescription(), notatki.getText()));
            return new ResponseEntity<>(_notatka, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/notatki/{id}")
    public ResponseEntity<Notatka> updateNotatki(@PathVariable("id") long id, @RequestBody Notatka notatka) {
        Optional<Notatka> notatkiData = notatkiRepository.findById(id);

        if (notatkiData.isPresent()) {
            Notatka _notatka = notatkiData.get();
            _notatka.setTitle(notatka.getTitle());
            _notatka.setDescription(notatka.getDescription());
            _notatka.setText(notatka.getText());
            return new ResponseEntity<>(notatkiRepository.save(_notatka), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/notatki/{id}")
    public ResponseEntity<HttpStatus> deleteNotatki(@PathVariable("id") long id) {
        try {
            notatkiRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/notatki")
    public ResponseEntity<HttpStatus> deleteAllNotatki() {
        try {
            notatkiRepository.deleteAll();
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }



}