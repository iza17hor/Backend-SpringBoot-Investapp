package com.example.X.repository;

import java.util.List;

import com.example.X.model.Notatka;
import org.springframework.data.jpa.repository.JpaRepository;


public interface NotatkaRepository extends JpaRepository<Notatka, Long> {
    List<Notatka> findByTitleContaining(String title);
}

