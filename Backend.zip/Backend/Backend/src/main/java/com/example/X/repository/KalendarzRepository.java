package com.example.X.repository;

import java.util.List;

import com.example.X.model.Kalendarz;
import com.example.X.model.Notatka;
import org.springframework.data.jpa.repository.JpaRepository;



public interface KalendarzRepository extends JpaRepository<Kalendarz, Long> {

    List<Kalendarz> findByEventContaining(String title);
}