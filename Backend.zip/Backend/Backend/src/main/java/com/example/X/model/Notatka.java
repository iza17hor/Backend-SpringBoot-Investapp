package com.example.X.model;
import javax.persistence.*;

@Entity
@Table(name = "notatka")
public class Notatka {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;
    @Column(name = "title")
    private String title;
    @Column(name = "description")
    private String description;
    @Column(name = "text")
    private String text;

    public Notatka() {}
    public Notatka(String title, String description, String text) {
        this.title = title;
        this.description = description;
        this.text = text;
    }
    public long getId() {
        return id;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getText() {
        return text;
    }
    public void setText(String text) {
        this.text = text;
    }
    @Override
    public String toString() {
        return "Notatka [id=" + id + ", title=" + title + ", desc=" + description + ", text=" + text +   "]";
    }
}