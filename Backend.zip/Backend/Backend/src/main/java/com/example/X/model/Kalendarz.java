package com.example.X.model;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonFormat.Shape;
import javax.persistence.*;
@Entity
@Table(name = "kalendarz")
public class Kalendarz {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    @Column(name = "event")
    private String event;

    @JsonFormat(pattern = "yyyy-MM-dd", shape = Shape.STRING)
    @Column(name = "start_date")
    private String startDate;

    @Column(name = "details")
    private String details;

    public Kalendarz() {

    }
    public Kalendarz(String event, String startDate,  String details) {
        this.event = event;
        this.startDate = startDate;
        this.details = details;



    }

    public long getId() {
        return id;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getStartDate(){
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    @Override
    public String toString() {
        return "Kalendarz [id=" + id + ", event=" + event + ", start=" + startDate  + ", details=" + details +   "]";
    }

}
