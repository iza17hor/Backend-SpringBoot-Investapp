package com.example.X.controller;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.example.X.model.Kalendarz;


import com.example.X.repository.KalendarzRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin(origins = "http://localhost:8080")
@RestController
@RequestMapping("/api")
public class KalendarzController {

    @Autowired
    KalendarzRepository kalendarzRepository;

    @GetMapping("/kalendarz")
    public ResponseEntity<List<Kalendarz>> getAllKalendarze(@RequestParam(required = false) String event) {
        try {
            List<Kalendarz> kalendarz = new ArrayList<Kalendarz>();

            if (event == null)
                kalendarzRepository.findAll().forEach(kalendarz::add);
            else
                kalendarzRepository.findByEventContaining(event).forEach(kalendarz::add);

            if (kalendarz.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }

            return new ResponseEntity<>(kalendarz, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/kalendarz/{id}")
    public ResponseEntity<Kalendarz> getKalendarzById(@PathVariable("id") long id) {
        Optional<Kalendarz> kalendarzData = kalendarzRepository.findById(id);

        if (kalendarzData.isPresent()) {
            return new ResponseEntity<>(kalendarzData.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/kalendarz")
    public ResponseEntity<Kalendarz> createKalendarz(@RequestBody Kalendarz kalendarz) {
        try {
            Kalendarz _kalendarz = kalendarzRepository.save(new Kalendarz(kalendarz.getEvent(),kalendarz.getStartDate(),  kalendarz.getDetails()));
            return new ResponseEntity<>(_kalendarz, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/kalendarz/{id}")
    public ResponseEntity<Kalendarz> updateKalendarz(@PathVariable("id") long id, @RequestBody Kalendarz kalendarz) {
        Optional<Kalendarz> kalendarzData = kalendarzRepository.findById(id);

        if (kalendarzData.isPresent()) {
            Kalendarz _kalendarz = kalendarzData.get();
            _kalendarz.setEvent(kalendarz.getEvent());
            _kalendarz.setStartDate(kalendarz.getStartDate());

            _kalendarz.setDetails(kalendarz.getDetails());
            return new ResponseEntity<>(kalendarzRepository.save(_kalendarz), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/kalendarz/{id}")
    public ResponseEntity<HttpStatus> deleteKalendarz(@PathVariable("id") long id) {
        try {
            kalendarzRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/kalendarz")
    public ResponseEntity<HttpStatus> deleteAllKalendarze() {
        try {
            kalendarzRepository.deleteAll();
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }



}